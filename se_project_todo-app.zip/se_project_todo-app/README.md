# Simple Todo App

Give a brief description of the project here. Feel free to give it a different name.

## Functionality

Give a more detailed explanation of the project and its functionality.

## Technology

Give a description of the technologies and techniques used. Pictures, GIFs, or screenshots that detail the project features are recommended.

## Deployment

This project is deployed on GitHub Pages:

- ADD LINK HERE
